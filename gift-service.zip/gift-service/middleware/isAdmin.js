const jwt = require("jsonwebtoken")
const User = require("../models/User")

async function isAdmin(req, res, next) {
	try {
		const token = req.headers.authorization.split(" ")[1] // Получаем токен из заголовка
		const decoded = jwt.verify(token, "secret_key") // Проверяем токен
		const user = await User.findById(decoded.id) // Находим пользователя по ID из токена

		if (!user || !user.isAdmin) {
			return res.status(403).json({ message: "Доступ запрещён" }) // Если не админ, возвращаем ошибку
		}

		req.user = user // Сохраняем пользователя в запросе
		next() // Переходим к следующему middleware или маршруту
	} catch (error) {
		return res.status(401).json({ message: "Необходима авторизация" }) // Если токен недействителен
	}
}

module.exports = isAdmin
