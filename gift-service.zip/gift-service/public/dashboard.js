// Navbar
const navToggle = document.querySelector(".nav-toggle")
const links = document.querySelector(".links")

navToggle.addEventListener("click", function () {
	links.classList.toggle("show-links")
})

document.addEventListener("DOMContentLoaded", () => {
	const token = localStorage.getItem("token")
	if (!token) {
		window.location.href = "index.html" // Переадресация на главную страницу при отсутствии токена.
	}

	const userInfo = document.getElementById("user-info")
	userInfo.innerHTML = `<p>Вы вошли как: <span>${localStorage.getItem(
		"username"
	)}</span></p>`

	const isAdmin = localStorage.getItem("isAdmin") === "true"
	if (isAdmin) {
		document.getElementById("admin-reviews-section").style.display = "block" // Показываем раздел администратора.
	}

	loadUserReviews() // Загружаем отзывы пользователя.
	loadFavorites() // Загружаем избранные продукты пользователя.
})

// Функция для генерации звёзд на основе оценки
function generateStars(rating) {
	let stars = ""
	for (let i = 1; i <= 5; i++) {
		if (i <= rating) {
			stars += `<img src="/assets/icons/star/star.png" style="width: 15px;" alt="star" />` // Заполненная звезда
		} else {
			stars += `<img src="/assets/icons/star/empty-star.png" style="width: 15px;" alt="empty star" />` // Пустая звезда
		}
	}
	return stars
}

// Загрузка отзывов пользователя.
async function loadUserReviews() {
	const userId = localStorage.getItem("userId")

	try {
		const response = await fetch(
			`http://localhost:3000/api/reviews/user/${userId}`
		)

		if (!response.ok) {
			throw new Error("Ошибка при загрузке отзывов.")
		}

		const reviews = await response.json()
		const userReviewsDiv = document.getElementById("user-reviews")
		userReviewsDiv.innerHTML = "" // Очистка перед добавлением новых отзывов.

		if (reviews.length === 0) {
			userReviewsDiv.innerHTML += "<p>У вас нет отзывов.</p>"
			return
		}

		reviews.forEach(review => {
			userReviewsDiv.innerHTML += `
                <div class='review-card'>
                    <p><span>${review.username}</span>: ${review.text}</p>
                    <p>Оценка: ${generateStars(review.rating)}</p>
                    <button onclick="deleteReview('${
											review._id
										}')">Удалить</button>
                </div>`
		})
	} catch (error) {
		console.error(error)
		alert(error.message)
	}
}

// Загрузка избранных продуктов пользователя.
async function loadFavorites() {
	const userId = localStorage.getItem("userId")

	try {
		const response = await fetch(
			`http://localhost:3000/api/favorites/${userId}`
		)

		if (!response.ok) {
			throw new Error("Ошибка при загрузке избранных продуктов.")
		}

		const favorites = await response.json()
		const favoritesListDiv = document.getElementById("favorites-list")
		favoritesListDiv.innerHTML = "" // Очистка перед добавлением новых продуктов.

		if (favorites.length === 0) {
			favoritesListDiv.innerHTML += "<p>У вас нет избранных продуктов.</p>"
			return
		}

		favorites.forEach(favorite => {
			favoritesListDiv.innerHTML += `
                <div class='product-card'>
                    <h4>${favorite.name}</h4>
                    <p>Цена: <span>${favorite.price} </span>руб.</p>
                    <img src="${favorite.image_url}" alt="${favorite.name}" style='width: 100px;'/>
                    <button onclick="removeFavorite('${favorite._id}')">Удалить</button>
                </div>`
		})
	} catch (error) {
		console.error(error)
		alert(error.message)
	}
}

// Удаление продукта из избранного.
async function removeFavorite(productId) {
	const userId = localStorage.getItem("userId")

	try {
		const response = await fetch(
			`http://localhost:3000/api/favorites/${userId}/${productId}`,
			{
				method: "DELETE",
			}
		)

		if (!response.ok) {
			throw new Error("Ошибка при удалении продукта из избранного.")
		}

		alert("Продукт был успешно удалён из избранного.")
		loadFavorites() // Обновляем список после удаления.
	} catch (error) {
		alert(`Ошибка: ${error.message}`)
		console.error("Ошибка:", error)
	}
}

// Выход из системы.
function logout() {
	localStorage.removeItem("token")
	localStorage.removeItem("username")
	localStorage.removeItem("userId")
	localStorage.removeItem("isAdmin") // Удаляем информацию о роли.
	window.location.href = "index.html" // Переадресация на главную страницу.
}

// Отправка отзыва.
async function submitReview() {
	const text = document.getElementById("review-text").value.trim()
	const rating = parseInt(document.getElementById("review-rating").value)

	if (!text || !rating) {
		alert("Пожалуйста заполните все поля.")
		return
	}

	const userId = localStorage.getItem("userId")
	const username = localStorage.getItem("username")

	try {
		const response = await fetch("http://localhost:3000/api/reviews", {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({ username, text, rating, userId }),
		})

		if (!response.ok) {
			const errorData = await response.json() // Получаем текст ошибки.
			console.error("Ошибка ответа сервера:", errorData)
			throw new Error(errorData.message) // Бросаем ошибку с текстом ответа.
		}

		document.getElementById("review-text").value = ""
		document.getElementById("review-rating").value = ""
		loadUserReviews() // Обновляем список отзывов.
	} catch (error) {
		alert(`Ошибка:${error.message}`)
		console.error("Ошибка:", error)
	}
}

// Удаление отзыва.
async function deleteReview(reviewId) {
	try {
		const response = await fetch(
			`http://localhost:3000/api/reviews/${reviewId}`,
			{ method: "DELETE" }
		)

		if (!response.ok) {
			throw new Error("Ошибка при удалении отзыва.")
		}

		alert("Отзыв был успешно удалён.")
		loadUserReviews() // Обновляем список после удаления.
	} catch (error) {
		alert(`Ошибка:${error.message}`)
		console.error("Ошибка:", error)
	}
}

// Загрузка всех отзывов для администратора.
async function loadAllReviews() {
	try {
		const response = await fetch(`http://localhost:3000/api/reviews`)

		if (!response.ok) {
			throw new Error("Ошибка при загрузке всех отзывов.")
		}

		const reviews = await response.json()
		const allReviewsDiv = document.getElementById("all-reviews")

		allReviewsDiv.innerHTML = "" // Очистка перед добавлением новых отзывов.

		reviews.forEach(review => {
			allReviewsDiv.innerHTML += `
                <div class='review-card'>
                    <p><span>${review.username}</span>: ${review.text}</p>
                    <p>Оценка: ${generateStars(
											review.rating
										)}</p> <!-- Используем функцию для отображения звёзд -->
                    <button onclick="deleteReview('${
											review._id
										}')">Удалить</button>
                </div>`
		})
	} catch (error) {
		console.error(error)
		alert(error.message)
	}
}
