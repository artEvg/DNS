// Navbar toggle functionality
const navToggle = document.querySelector(".nav-toggle")
const links = document.querySelector(".links")

navToggle.addEventListener("click", function () {
	links.classList.toggle("show-links")
})

const preloader = document.querySelector(".preloader")

window.addEventListener("load", function () {
	preloader.classList.add("hide-preloader")
})

// Modal functionality
const modalBtn = document.querySelector(".modal-btn")
const modal = document.querySelector(".modal-overlay")
const closeBtn = document.querySelector(".close-btn")
const authSection = document.getElementById("auth-section")

modalBtn.addEventListener("click", function () {
	authSection.classList.remove("hidden") // Убираем класс скрытия
	modal.classList.add("open-modal")
})

closeBtn.addEventListener("click", function () {
	modal.classList.remove("open-modal")
	authSection.classList.add("hidden") // Добавляем класс скрытия при закрытии
})

modalBtn.addEventListener("click", function () {
	// Сброс содержимого модального окна перед открытием
	authSection.style.display = "block" // или используйте другой метод для отображения
	modal.classList.add("open-modal")
})

closeBtn.addEventListener("click", function () {
	modal.classList.remove("open-modal")
})

// Закрытие модального окна при клике вне него
modal.addEventListener("click", function (e) {
	if (e.target === modal) {
		modal.classList.remove("open-modal")
	}
})

function toggleAuth() {
	const authSection = document.getElementById("auth-section")
	if (authSection.style.display === "none") {
		authSection.style.display = "block" // Показываем разделы регистрации и входа
	} else {
		authSection.style.display = "none" // Скрываем разделы
	}
}

async function register() {
	const username = document.getElementById("reg-username").value.trim()
	const password = document.getElementById("reg-password").value.trim()
	const passwordConfirm = document
		.getElementById("reg-password-confirm")
		.value.trim()

	// Валидация
	if (!username || !password || !passwordConfirm) {
		alert("Пожалуйста, заполните все поля.")
		return
	}

	if (username.length < 3) {
		alert("Имя пользователя должно содержать не менее 3 символов.")
		return
	}

	if (password.length < 6) {
		alert("Пароль должен содержать не менее 6 символов.")
		return
	}

	if (password !== passwordConfirm) {
		alert("Пароли не совпадают.")
		return
	}

	try {
		const response = await fetch("http://localhost:3000/api/auth/register", {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({ username, password }),
		})

		if (!response.ok) {
			const errorData = await response.text()
			console.error("Ошибка ответа сервера:", errorData)
			throw new Error(errorData)
		}

		const data = await response.json()

		// Сохранение данных пользователя в localStorage
		localStorage.setItem("token", data.token)
		localStorage.setItem("username", username)
		localStorage.setItem("userId", data.userId)
		localStorage.setItem("isAdmin", data.isAdmin) // Сохраняем информацию о роли

		alert("Регистрация успешна!")

		clearRegistrationFields()

		const modal = document.querySelector(".modal-overlay")
		modal.classList.remove("open-modal")
	} catch (error) {
		alert(`Ошибка: ${error.message}`)
		console.error("Ошибка:", error)
	}
}

async function login() {
	const username = document.getElementById("login-username").value.trim()
	const password = document.getElementById("login-password").value.trim()

	if (!username || !password) {
		alert("Пожалуйста, заполните все поля.")
		return
	}

	try {
		const response = await fetch("http://localhost:3000/api/auth/login", {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({ username, password }),
		})

		if (!response.ok) {
			const errorData = await response.text()
			console.error("Ошибка ответа сервера:", errorData)
			throw new Error(errorData)
		}

		const data = await response.json()

		localStorage.setItem("token", data.token)
		localStorage.setItem("username", username)
		localStorage.setItem("userId", data.userId)
		localStorage.setItem("isAdmin", data.isAdmin) // Сохраняем информацию о роли

		alert("Вход успешен!")

		const modal = document.querySelector(".modal-overlay")
		modal.classList.remove("open-modal")

		clearLoginFields()
	} catch (error) {
		alert(`Ошибка: ${error.message}`)
		console.error("Ошибка:", error)
	}
}

// Очистка полей формы регистрации и входа
function clearRegistrationFields() {
	document.getElementById("reg-username").value = ""
	document.getElementById("reg-password").value = ""
	document.getElementById("reg-password-confirm").value = ""
}

function clearLoginFields() {
	document.getElementById("login-username").value = ""
	document.getElementById("login-password").value = ""
}

// Переход в личный кабинет
function goToDashboard() {
	window.location.href = "dashboard.html" // Переадресация на личный кабинет
}

function openSurvey() {
	document.getElementById("survey-modal").style.display = "block" // Показываем модальное окно опроса
}

function closeSurvey() {
	document.getElementById("survey-modal").style.display = "none" // Скрываем модальное окно опроса
}

async function submitSurvey() {
	const category1 = document.getElementById("question1").value
	const minPrice = parseFloat(document.getElementById("min-price").value) || 0
	const maxPrice =
		parseFloat(document.getElementById("max-price").value) || Infinity

	if (!category1) {
		alert("Пожалуйста, выберите хотя бы одну категорию.")
		return
	}

	const selectedCategories = [category1] // Добавьте остальные категории в массив

	try {
		const response = await fetch(
			`http://localhost:3000/api/products?categories=${selectedCategories.join(
				","
			)}&minPrice=${minPrice}&maxPrice=${maxPrice}`
		)

		if (!response.ok) {
			throw new Error("Ошибка при получении продуктов")
		}

		const products = await response.json()

		const filteredProducts = products.filter(
			product =>
				selectedCategories.includes(product.category) &&
				product.price >= minPrice &&
				product.price <= maxPrice
		)

		const selectedProducts = filteredProducts.slice(0, 5) // Ограничиваем количество выводимых продуктов до 5

		displayProducts(selectedProducts)
		closeSurvey() // Закрываем модальное окно после обработки
	} catch (error) {
		console.error("Ошибка при получении продуктов:", error)
	}
}

function displayProducts(products) {
	const productsContainer = document.getElementById("products")
	productsContainer.innerHTML = "" // Очищаем предыдущие продукты

	if (products.length === 0) {
		productsContainer.innerHTML = "<p>Нет подходящих продуктов.</p>"
		return
	}

	products.forEach(product => {
		const productDiv = document.createElement("span")
		productDiv.className = "product"

		productDiv.innerHTML = `
         <h3>${product.name}</h3>
         <p>Категория: ${product.category}</p>
         <p>Цена: <span>${product.price}</span> руб.</p>
         <img src="${product.image_url}" alt="${product.name}" style='width: 200px;'/>
         <button onclick='addToFavorites("${product._id}")'>Добавить в избранное</button>
     `

		productsContainer.appendChild(productDiv)
	})
}

// Добавление продукта в избранное
async function addToFavorites(productId) {
	const userId = localStorage.getItem("userId")

	try {
		const response = await fetch("http://localhost:3000/api/favorites/add", {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({ userId, productId }),
		})

		if (!response.ok) {
			throw new Error("Ошибка при добавлении в избранное.")
		}

		alert("Продукт добавлен в избранное!")
	} catch (error) {
		alert(`Ошибка: ${error.message}`)
		console.error("Ошибка:", error)
	}
}
// Функции для работы с отзывами

let products = []
let filteredProducts = []

// Функция для загрузки всех продуктов из базы данных
async function loadProducts() {
	try {
		const response = await fetch("http://localhost:3000/api/products")
		products = await response.json()
		displayProducts(products)
	} catch (error) {
		console.error("Ошибка при загрузке продуктов:", error)
	}
}

// Функция для отображения всех продуктов
function showAllProductsDiv() {
	displayProducts(products)
}

// Функция для фильтрации продуктов по категории
async function filterProducts(category) {
	if (category === "Все") {
		showAllProductsDiv()
		return
	}

	filteredProducts = products.filter(product => product.category === category)
	displayProducts(filteredProducts)
}

// Функция для поиска продуктов по имени
function searchProducts() {
	const searchValue = document
		.getElementById("search-input")
		.value.toLowerCase()
	const searchedProducts = products.filter(product =>
		product.name.toLowerCase().includes(searchValue)
	)
	displayProducts(searchedProducts)
}

// Функция для отображения продуктов на странице
function displayProducts(productsToDisplay) {
	const productsContainer = document.getElementById("productsDiv")
	productsContainer.innerHTML = "" // Очищаем предыдущие продукты

	if (productsToDisplay.length === 0) {
		productsContainer.innerHTML = "<p>Нет подходящих продуктов.</p>"
		return
	}

	productsToDisplay.forEach(product => {
		const productDiv = document.createElement("div")
		productDiv.className = "product"
		productDiv.innerHTML = `
            <h3>${product.name}</h3>
            <p>Категория: ${product.category}</p>
            <p>Цена: <span>${product.price}</span> руб.</p>
            <img src="${product.image_url}" alt="${product.name}" style=''/>
            <button onclick='addToFavorites("${product._id}")'>Добавить в избранное</button>
        `
		productsContainer.appendChild(productDiv)
	})
}

async function submitReview() {
	const text = document.getElementById("review-text").value.trim()
	const rating = parseInt(document.getElementById("review-rating").value)

	if (!text || !rating) {
		alert("Пожалуйста, заполните все поля.")
		return
	}

	const userId = localStorage.getItem("userId")
	const username = localStorage.getItem("username")

	try {
		const response = await fetch("http://localhost:3000/api/reviews", {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({ username, text, rating, userId }),
		})

		if (!response.ok) {
			throw new Error("Ошибка при отправке отзыва")
		}

		document.getElementById("review-text").value = ""
		document.getElementById("review-rating").value = ""

		loadUserReviews() // Обновляем список отзывов
	} catch (error) {
		alert(`Ошибка: ${error.message}`)
		console.error("Ошибка:", error)
	}
}

const questions = document.querySelectorAll(".question")

questions.forEach(function (question) {
	const btn = question.querySelector(".question-btn")
	btn.addEventListener("click", function () {
		questions.forEach(function (item) {
			if (item !== question) {
				item.classList.remove("show-text")
			}
		})

		question.classList.toggle("show-text")
	})
})

async function loadUserReviews() {
	const userId = localStorage.getItem("userId")

	try {
		const response = await fetch(
			`http://localhost:3000/api/reviews/user/${userId}`
		)

		if (!response.ok) {
			throw new Error("Ошибка при получении отзывов")
		}

		const reviews = await response.json()

		const reviewsContainer = document.getElementById("user-reviews")
		reviewsContainer.innerHTML = "" // Очистка перед добавлением новых элементов

		reviews.forEach(review => {
			const reviewDiv = document.createElement("div")
			reviewDiv.innerHTML = `
               <p><strong>${review.username}</strong>: ${review.text} (Оценка: ${review.rating})</p>
               <button onclick="deleteReview('${review._id}')">Удалить</button>
           `
			reviewsContainer.appendChild(reviewDiv)
		})
	} catch (error) {}
}

async function deleteReview(reviewId) {
	try {
		const response = await fetch(
			`http://localhost:3000/api/reviews/${reviewId}`,
			{ method: "DELETE" }
		)

		if (!response.ok) {
			throw new Error("Ошибка при удалении отзыва")
		}

		loadUserReviews() // Обновляем список после удаления
	} catch (error) {
		alert(`Ошибка: ${error.message}`)
		console.error("Ошибка:", error)
	}
}

// Вызов функции загрузки пользовательских отзывов при загрузке страницы
window.onload = function () {
	loadUserReviews() // Загружаем отзывы пользователя
	loadProducts()
}

const reviews = [
	{
		id: 1,
		name: "Мария",
		job: "★ ★ ★ ★ ☆",
		img: "https://img.freepik.com/free-photo/young-blonde-woman-red-shirt_273609-19227.jpg?t=st=1733928441~exp=1733932041~hmac=98f86dbd00f36b593a526fd249e77e6914abc4f70209e9849c76d72f8958ffa5&w=1380",
		text: "Хороший выбор электроники и доступные цены. Заказала iphone 16, и он пришел с небольшим опозданием, но менеджер магазина оперативно связался и объяснил ситуацию. В целом, рекомендую!",
	},
	{
		id: 2,
		name: "Сергей",
		job: "★ ★ ★ ★ ★",
		img: "https://img.freepik.com/free-photo/man-hipster-hair-bearded-s_1303-1877.jpg?t=st=1733928839~exp=1733932439~hmac=7003c305994d9b516c0d0548828aa546a532faeef69f60ab0c462aabfdf7ee0b&w=1380",
		text: "Прекрасный сервис и отличные цены! Купил телевизор с большой скидкой. Доставка была бесплатной, а курьер аккуратно установил его в квартире. Очень доволен покупкой!",
	},
	{
		id: 3,
		name: "Алексей",
		job: "★ ★ ★ ★ ★",
		img: "https://img.freepik.com/free-photo/young-serious-man-sitting-bench-park_23-2148193868.jpg?t=st=1733928408~exp=1733932008~hmac=5c8567acd1c72c13ff0d2048a314409f3c9f61c5a53995674ab3b2a678781b90&w=1380",
		text: "Отличный магазин! Заказал смартфон с доставкой на следующий день, и он пришел в идеальном состоянии. Очень доволен качеством обслуживания и быстрой доставкой!",
	},
	{
		id: 4,
		name: "Игорь",
		job: "★ ★ ★ ★ ★",
		img: "https://img.freepik.com/free-photo/young-adult-having-great-time-with-friends_23-2149286481.jpg?t=st=1733928696~exp=1733932296~hmac=62171276904ad578e4b552ecaeae91d55c29543695ea8991b7eee0562119af99&w=1380",
		text: "Покупал наушники, и они превзошли все ожидания! Звук отличный, а доставка была быстрой. Обязательно вернусь за новыми покупками!",
	},
]

const img = document.getElementById("person-img")
const author = document.getElementById("author")
const job = document.getElementById("job")
const info = document.getElementById("info")

const prevBtn = document.querySelector(".prev-btn")
const nextBtn = document.querySelector(".next-btn")
const randomBtn = document.querySelector(".random-btn")

let currentItem = 0

window.addEventListener("DOMContentLoaded", function () {
	showPerson()
})

function showPerson() {
	const item = reviews[currentItem]
	img.src = item.img
	author.textContent = item.name
	job.textContent = item.job
	info.textContent = item.text
}

nextBtn.addEventListener("click", function () {
	currentItem++
	if (currentItem > reviews.length - 1) {
		currentItem = 0
	}
	showPerson()
})

prevBtn.addEventListener("click", function () {
	currentItem--
	if (currentItem < 0) {
		currentItem = reviews.length - 1
	}
	showPerson()
})

// Получаем кнопку
const scrollToTopButton = document.getElementById("scrollToTop")

// Показываем кнопку при прокрутке вниз
window.addEventListener("scroll", function () {
	if (window.scrollY > 300) {
		scrollToTopButton.style.display = "block" // Показываем кнопку
	} else {
		scrollToTopButton.style.display = "none" // Скрываем кнопку
	}
})

// Обработчик события клика по кнопке
scrollToTopButton.addEventListener("click", function () {
	window.scrollTo({
		top: 0,
		behavior: "smooth",
	})
})
