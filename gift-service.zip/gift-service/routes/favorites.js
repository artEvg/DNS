const express = require("express")
const User = require("../models/User")
const Product = require("../models/Product")
const router = express.Router()

// Добавление продукта в избранное
router.post("/add", async (req, res) => {
	const { userId, productId } = req.body

	try {
		const user = await User.findById(userId)
		if (!user) {
			return res.status(404).json({ message: "Пользователь не найден" })
		}

		if (!user.favorites.includes(productId)) {
			user.favorites.push(productId)
			await user.save()
		}

		res.status(200).json({ message: "Продукт добавлен в избранное" })
	} catch (error) {
		res.status(500).json({ message: error.message })
	}
})

// Получение избранных продуктов пользователя
router.get("/:userId", async (req, res) => {
	try {
		const user = await User.findById(req.params.userId).populate("favorites")
		if (!user) {
			return res.status(404).json({ message: "Пользователь не найден" })
		}

		res.json(user.favorites) // Возвращаем избранные продукты
	} catch (error) {
		res.status(500).json({ message: error.message })
	}
})

// Удаление продукта из избранного
router.delete("/:userId/:productId", async (req, res) => {
	const { userId, productId } = req.params

	try {
		const user = await User.findById(userId)

		if (!user) {
			return res.status(404).json({ message: "Пользователь не найден." })
		}

		// Удаляем продукт из массива избранных
		user.favorites.pull(productId)
		await user.save()

		res.status(200).json({ message: "Продукт успешно удалён из избранного." })
	} catch (error) {
		console.error(error)
		res
			.status(500)
			.json({ message: "Ошибка при удалении продукта из избранного." })
	}
})

module.exports = router
