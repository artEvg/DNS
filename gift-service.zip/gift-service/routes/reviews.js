const express = require("express")
const Review = require("../models/Review")
const router = express.Router()

// Создание нового отзыва
router.post("/", async (req, res) => {
	const { username, text, rating, userId } = req.body

	try {
		const review = new Review({ username, text, rating, userId })
		await review.save()
		res.status(201).json(review)
	} catch (error) {
		res.status(400).json({ message: error.message })
	}
})

// Получение всех отзывов для пользователя по userId
router.get("/user/:userId", async (req, res) => {
	try {
		const reviews = await Review.find({ userId: req.params.userId })
		res.json(reviews)
	} catch (error) {
		res.status(500).json({ message: error.message })
	}
})

// Получение всех отзывов для администратора
router.get("/", async (req, res) => {
	try {
		const reviews = await Review.find({})
		res.json(reviews)
	} catch (error) {
		res.status(500).json({ message: error.message })
	}
})

// Удаление отзыва по ID
router.delete("/:id", async (req, res) => {
	try {
		await Review.findByIdAndDelete(req.params.id)
		res.status(204).send()
	} catch (error) {
		res.status(500).json({ message: error.message })
	}
})

module.exports = router
