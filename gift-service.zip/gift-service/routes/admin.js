const express = require("express")
const Review = require("../models/Review")
const router = express.Router()

// Получение всех отзывов для администратора
router.get("/reviews", async (req, res) => {
	try {
		const reviews = await Review.find({})
		res.json(reviews)
	} catch (error) {
		res.status(500).json({ message: error.message })
	}
})

// Удаление отзыва по ID
router.delete("/reviews/:id", async (req, res) => {
	try {
		await Review.findByIdAndDelete(req.params.id)
		res.status(204).send()
	} catch (error) {
		res.status(500).json({ message: error.message })
	}
})

module.exports = router
