const express = require("express")
const Product = require("../models/Product")
const router = express.Router()

// Получение списка продуктов
router.get("/", async (req, res) => {
	try {
		const products = await Product.find({})
		res.json(products)
	} catch (error) {
		res.status(500).json({ message: "Ошибка получения продуктов" })
	}
})

// Добавление продукта (только для админа)
router.post("/", async (req, res) => {
	const product = new Product(req.body)

	try {
		await product.save()
		res.status(201).send("Продукт добавлен")
	} catch (error) {
		res.status(400).send("Ошибка добавления продукта")
	}
})

// Получение продуктов по категории
router.get("/category", async (req, res) => {
	try {
		const products = await Product.find({ category: req.params.category })
		res.json(products)
	} catch (error) {
		res.status(500).json({ message: error.message })
	}
})

module.exports = router

module.exports = router
