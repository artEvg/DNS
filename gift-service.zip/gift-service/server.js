const express = require("express")
const mongoose = require("mongoose")
const cors = require("cors")
const bodyParser = require("body-parser")
const bcrypt = require("bcryptjs")
const User = require("./models/User")
const Product = require("./models/Product")
const Review = require("./models/Review")

// Подключаем маршруты
const authRoutes = require("./routes/auth")
const productRoutes = require("./routes/products")
const reviewRoutes = require("./routes/reviews")
const favoritesRoutes = require("./routes/favorites") // Подключаем маршруты для избранных продуктов

const app = express()
app.use(cors())
app.use(bodyParser.json())
app.use(express.static("public"))

// Подключение к базе данных MongoDB
mongoose
	.connect("mongodb://localhost/gift_service")
	.then(() => console.log("Подключение к MongoDB успешно"))
	.catch(err => console.error("Ошибка подключения к MongoDB:", err))

// Создание учётной записи администратора при запуске приложения
async function createAdmin() {
	const adminExists = await User.findOne({ username: "admin" })

	if (!adminExists) {
		const hashedPassword = await bcrypt.hash("admin123", 10)
		const adminUser = new User({
			username: "admin",
			password: hashedPassword,
			isAdmin: true,
		})
		await adminUser.save()
		console.log("Учётная запись администратора создана")
	} else {
		console.log("Учётная запись администратора уже существует")
	}
}

// Создание учётной записи администратора при запуске приложения
createAdmin()

// Используем маршруты
app.use("/api/auth", authRoutes)
app.use("/api/products", productRoutes)
app.use("/api/reviews", reviewRoutes)
app.use("/api/favorites", favoritesRoutes) // Добавляем маршруты для избранных продуктов

// Запуск сервера
app.listen(3000, () => {
	console.log("Сервер запущен на порту 3000")
})
