const mongoose = require("mongoose")
const Product = require("./models/Product") // Импортируем модель продукта

// Подключение к базе данных
mongoose
	.connect("mongodb://localhost/gift_service")
	.then(() => console.log("Подключение к MongoDB успешно"))
	.catch(err => console.error("Ошибка подключения к MongoDB:", err))

// Данные для заполнения
const products = [
	// Электроника
	{
		name: "Телевизор Samsung LED CU7100",
		category: "Электроника",
		price: 35.999,
		image_url:
			"https://online-samsung.ru/sites/default/files/styles/product_full/public/2024-05/UE43CU7100UXRU_7-min.png.webp?itok=xtHWRMd_",
	},
	{
		name: "Портативная колонка JBL Pulse 4 Black",
		category: "Электроника",
		price: 28.369,
		image_url:
			"https://static.insales-cdn.com/r/POpqylhMP6w/rs:fit:1000:0:1/plain/images/products/1/7752/787832392/Screenshot_11_23ub-a3_png__19_.jpg@webp",
	},
	{
		name: "Проектор Xiaomi Mi 4K Laser Projector черный",
		category: "Электроника",
		price: 199.999,
		image_url:
			"https://c.dns-shop.ru/thumb/st1/fit/500/500/463c1bd2e4a491c2b70a301abd4cb172/f74690f85631ff03b9b5eeebc44d64879cf951ccd2eeb452517ed9e8402cbc9a.jpg.webp",
	},
	{
		name: "Микроволновая печь Eigen MW-FBE900I чёрный",
		category: "Электроника",
		price: 12.399,
		image_url:
			"https://c.dns-shop.ru/thumb/st4/fit/500/500/25919c90f259fe1ae4cbc334e560e498/5f612a3a66434c86aefc27df29ff506bc450ec1cc1028b2369d8a0d56c6af62c.jpg.webp",
	},
	{
		name: "Умная светодиодная лампа Xiaomi Mi Smart LED",
		category: "Электроника",
		price: 1.349,
		image_url:
			"https://c.dns-shop.ru/thumb/st4/fit/500/500/970be4b91863e8c5cec8b02f7894ec95/79deb8a48c5e984f9272d312035faa97943defb64b0e3b1f3aa1501b1a2d0e15.jpg.webp",
	},

	// Комплектующие для ПК
	{
		name: "Видеокарта GIGABYTE GeForce RTX 4070 Ti SUPER GAMING OC",
		category: "Комплектующие для ПК",
		price: 129.999,
		image_url:
			"https://c.dns-shop.ru/thumb/st1/fit/500/500/15a165554ffe28b319c48a48f8226dcd/09dfc698fc36c4f815e70d2a89f5d20cba914ec3b79297974f4c9dab9ab8a885.jpg.webp",
	},
	{
		name: "Материнская плата ASUS ROG STRIX Z790-F GAMING WIFI",
		category: "Комплектующие для ПК",
		price: 53.499,
		image_url:
			"https://c.dns-shop.ru/thumb/st4/fit/500/500/ac426dd5f6d65a44f30e8274b86399e5/15e60b0fef7890b9d9ec61930d0001d6b699ce52da1e27629da20e848b74e70d.jpg.webp",
	},
	{
		name: "Оперативная память ADATA XPG Lancer Blade RGB 32 ГБ",
		category: "Комплектующие для ПК",
		price: 13.499,
		image_url:
			"https://c.dns-shop.ru/thumb/st1/fit/500/500/d34cfcabc863cb718554dab975467b45/2acfe3f6dc3849684b2861755930169d807b321a731939c245a07260f8151b53.png.webp",
	},
	{
		name: "1000 ГБ M.2 NVMe накопитель Samsung 990 PRO",
		category: "Комплектующие для ПК",
		price: 14.699,
		image_url:
			"https://c.dns-shop.ru/thumb/st4/fit/500/500/b60c1ec8a195fc6bd4367a71e2f72533/c0e0fdbb70b14fa69e223b44b1ea251d48ea8fde682cf2a535075882a6c7a1aa.jpg.webp",
	},
	{
		name: "Блок питания Cooler Master XG750 PLATINUM черный",
		category: "Комплектующие для ПК",
		price: 20.799,
		image_url:
			"https://c.dns-shop.ru/thumb/st4/fit/500/500/6c9d4fe191dce121edf355a383bacee2/d6cd7fa33913c039f193c5978c5868eab658b95ee12fa3e5b22af59934013179.jpg.webp",
	},

	// Смартфоны
	{
		name: "Смартфон Samsung Galaxy S24 Ultra 512 ГБ черный",
		category: "Смартфоны",
		price: 129.999,
		image_url:
			"https://avatars.mds.yandex.net/get-goods_pic/6578279/hat2819ccb7a79fd2b39a6d4cae2d641f24/600x600",
	},
	{
		name: "Смартфон Apple iPhone 16 128 ГБ зеленый",
		category: "Смартфоны",
		price: 104.699,
		image_url:
			"https://c.dns-shop.ru/thumb/st1/fit/500/500/2ebb122f1abfb68b2c25fa0e49b21736/c23a471eea6575db2fb656e3cf3d97bce4659905aa8d104f36e85de13c43ec96.jpg.webp",
	},
	{
		name: "Смартфон Xiaomi 14 256 ГБ черный",
		category: "Смартфоны",
		price: 84.999,
		image_url:
			"https://c.dns-shop.ru/thumb/st4/fit/500/500/74a7f0fd5423534256f8e4d45ba9288d/312871a0ca23b0215148b4db745ab0f8bd96d910b5f6dd6101d1226f1498b8e7.jpg.webp",
	},
	{
		name: "Смартфон OnePlus Ace 2 Pro 1024 ГБ серый",
		category: "Смартфоны",
		price: 72.999,
		image_url:
			"https://c.dns-shop.ru/thumb/st4/fit/500/500/2f928fcfc93c42479e26847935b5a7c8/cd875d3cec085851111a1ae392e3a00bff95ba7c2888443655b99bab7e3dc459.jpg.webp",
	},
	{
		name: "Смартфон Google Pixel 9 128 ГБ черный",
		category: "Смартфоны",
		price: 110.499,
		image_url:
			"https://c.dns-shop.ru/thumb/st1/fit/500/500/926a7f60a97849f18ce4b9cc02083956/769c06f8946429f70fcf8a564b8c90ba2cd8c93197e0c76e442c1939a851c980.jpg.webp",
	},

	// Фотоаппараты
	{
		name: "Фотоаппарат Canon EOS R100 Kit 18-45mm F4.5-6.3 IS STM черный",
		category: "Фотоаппараты",
		price: 64.999,
		image_url:
			"https://c.dns-shop.ru/thumb/st1/fit/500/500/c75702c471d8ab82ad1a7c841a5dcd44/86cc02b4fa97587fe5498ff36dcbc8c9c1499053ceb5daec375f5003a120fe99.jpg.webp",
	},
	{
		name: "Фотоаппарат Nikon Z 6 II Body черный",
		category: "Фотоаппараты",
		price: 179.999,
		image_url:
			"https://c.dns-shop.ru/thumb/st1/fit/500/500/c93cdab7dac4d8cce492093f3b4c4c07/99921a043b8a7c155cebd77993242fa5fefba59ac49b066edb7a34c141ba13f7.jpg.webp",
	},
	{
		name: "Фотоаппарат Sony Alpha 7 III Body черный",
		category: "Фотоаппараты",
		price: 175.999,
		image_url:
			"https://c.dns-shop.ru/thumb/st4/fit/500/500/e9bd92b3304e04214f4272c1a73694fb/1ddfa7e302f54e81f9b9ae231fa8182fb6a9374ea6fc5234e11104a6b2cd4396.jpg.webp",
	},
	{
		name: "Фотоаппарат Fujifilm X-T4 Kit XF 16-80mm черный",
		category: "Фотоаппараты",
		price: 179.999,
		image_url:
			"https://c.dns-shop.ru/thumb/st4/fit/500/500/4d397b7cca996ba65febc46b09dfd4d0/82abcd242b5d79e6755b9fc9eba76caec2c11f0e6ba0929f810224c576bd7adf.jpg.webp",
	},
	{
		name: "фотоаппарат Panasonic Lumix DC-GH5 Body черный",
		category: "Фотоаппараты",
		price: 67.799,
		image_url:
			"https://c.dns-shop.ru/thumb/st1/fit/500/500/2d47949287d5c6efaaf8da196c84ced5/c17e424121558a224f96268fb3bb9aa3c5dc432e58ca2e0003a3f82c8ffc0240.jpg.webp",
	},

	// Аксессуары
	{
		name: "Наушники Sony WH-1000XM4 черный",
		category: "Аксессуары",
		price: 33.499,
		image_url:
			"https://c.dns-shop.ru/thumb/st4/fit/500/500/46ac14d06feb1c3209aaa48558438833/98b9e05e914b1509d829607b96d3dbd3df7295e8704604cb4c8e45c8cd788b6b.jpg.webp",
	},
	{
		name: "Накладка Pitaka StarPeak Tactile для Apple iPhone 16 синий/голубой",
		category: "Аксессуары",
		price: 9.299,
		image_url:
			"https://c.dns-shop.ru/thumb/st1/fit/500/500/75cacbfec7038ae93d51270d6a750520/9e5da9d36c3fad12c7be5e33d4fdd4c41afb1012b8b12901837f2814addb307e.jpg.webp",
	},
	{
		name: "Портативный аккумулятор Anker PowerCore Mag-Go 5000 белый",
		category: "Аксессуары",
		price: 4.599,
		image_url:
			"https://c.dns-shop.ru/thumb/st1/fit/500/500/bfd91c77e38093e11409f7639dbd8de8/2fae131a4856bfc47f3506d2fd71e4cfc8c0ada899f65fdddb3ca4cc8a05c5a8.jpg.webp",
	},
	{
		name: "Рюкзак Thule Crossover 2 Backpack синий",
		category: "Аксессуары",
		price: 32.299,
		image_url:
			"https://c.dns-shop.ru/thumb/st1/fit/500/500/0982be870ca4d60d87e26258c8ce6284/41c58e0e221ce79ed1d520c4032ff1bab931215e7690c9e5fa8534c729421586.jpg.webp",
	},
	{
		name: "Память USB Flash 128 ГБ SanDisk Ultra",
		category: "Аксессуары",
		price: 2.499,
		image_url:
			"https://c.dns-shop.ru/thumb/st1/fit/500/500/88ff8e1396363af2dc72470ba6d81ec6/265a0424c24e6806f952e69478f70cc32b367bdf22606abebf4c108b42222589.jpg.webp",
	},
]

// Функция для добавления продуктов в базу данных
async function seedDatabase() {
	try {
		await Product.deleteMany({}) // Удаляем все существующие продукты
		await Product.insertMany(products) // Добавляем новые продукты
		console.log("База данных успешно заполнена продуктами!")
		mongoose.connection.close() // Закрываем соединение с базой данных
	} catch (error) {
		console.error("Ошибка при заполнении базы данных:", error)
		mongoose.connection.close() // Закрываем соединение с базой данных даже при ошибке
	}
}

// Запуск функции добавления продуктов в базу данных
seedDatabase()
